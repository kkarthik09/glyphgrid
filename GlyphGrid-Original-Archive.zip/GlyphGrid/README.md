# GlyphGrid

A complete cross-platform puzzle game for Android and iOS, designed for players age 10 and older.

## Game concept

Players rotate overlapping 2×2 tile clusters to transform the main board into a target glyph pattern. The mechanic is simple to learn, but overlapping rotations create increasingly challenging spatial puzzles.

### Included

- 40 deterministic, guaranteed-solvable levels
- Progressive 3×3, 4×4, and 5×5 boards
- Daily puzzle generated locally from the date
- Clockwise and counterclockwise rotations
- Undo, restart, and intelligent hint controls
- 1–3 star scoring
- Local progress persistence
- Haptic feedback
- Responsive phone/tablet layout
- Accessibility labels
- No ads, login, network connection, or paid services

## Run locally

1. Install Node.js and the Expo Go app on your Android or iPhone.
2. In this project folder, run:

```bash
npm install
npx expo start
```

3. Scan the displayed QR code with Expo Go.

Android emulator:

```bash
npm run android
```

iOS Simulator requires macOS with Xcode:

```bash
npm run ios
```

## Create store-ready builds

Install Expo Application Services:

```bash
npm install -g eas-cli
eas login
eas build:configure
```

Android App Bundle:

```bash
eas build --platform android --profile production
```

iOS archive:

```bash
eas build --platform ios --profile production
```

You will need your own Apple Developer and Google Play Console accounts for store submission.

## Customize before publishing

- Change `ios.bundleIdentifier` and `android.package` in `app.json`.
- Replace the generated icon/splash artwork in `assets/` if desired.
- Update the app name, privacy policy URL, screenshots, age rating, and store descriptions.
- Test on multiple physical devices.

## Project structure

- `App.tsx` — navigation, screens, progress, gameplay UI
- `src/game/engine.ts` — board rotation, puzzle generation, hints, scoring
- `src/components/GlyphBoard.tsx` — reusable board renderer and controls
- `src/components/PrimaryButton.tsx` — reusable button
- `src/theme.ts` — palette and glyph definitions
- `app.json` — Expo Android/iOS metadata
- `eas.json` — cloud build profiles

## Notes

The dependency versions are pinned to a compatible Expo SDK set so the project remains reproducible. When upgrading Expo, use `npx expo install --fix` and test both platforms.
